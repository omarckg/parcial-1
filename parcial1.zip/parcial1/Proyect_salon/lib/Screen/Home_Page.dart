import 'package:flutter/material.dart';
import 'package:gyphi/Providers/Provider.dart'; // Asegúrate de importar correctamente tu Provider
import '../Models/Modelo.dart'; // Asegúrate de importar correctamente tu modelo

// Asegúrate de importar correctamente tu HomePage

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final welcomeProvider = WelcomeProvider(); // Instancia del Provider
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_scrollListener);
    _loadData();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _loadData();
    }
  }

  Future<void> _loadData() async {
    if (!_isLoading) {
      setState(() {
        _isLoading = true;
      });

      await welcomeProvider
          .fetchData(); // Llamada al método fetchData para cargar datos

      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final welcomeProvider = WelcomeProvider(); // Instancia del Provider

    return Scaffold(
      appBar: AppBar(title: const Text('Welcome Info')),
      body: FutureBuilder<void>(
        future: welcomeProvider
            .fetchData(), // Llamada al método fetchData para cargar datos
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            return ListView.builder(
              itemCount: welcomeProvider.welcomeList.length,
              itemBuilder: (context, index) {
                final welcome = welcomeProvider.welcomeList[index];
                return Card(
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  color: Colors.white, // Cambia el color de fondo
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(8), // Agrega bordes redondeados
                    // Puedes agregar más personalización aquí
                  ),
                  child: ListTile(
                    title: Text(welcome.razonSocial),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Organizacion: ${welcome.organizacion}'),
                        Text('Fecha de Renovación: ${welcome.fechaRenovacion}'),
                        Text('Email Comercial: ${welcome.emailComercial}'),
                        // Agrega más campos aquí...
                      ],
                    ),
                    onTap: () {
                      // Acción cuando se toca un elemento de la lista
                      _showDetailsDialog(
                          context, welcome); // Muestra el diálogo de detalles
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }

  void _showDetailsDialog(BuildContext context, Welcome welcome) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(welcome.razonSocial),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Matricula: ${welcome.matricula}'),
              Text('Ciuu1: ${welcome.ciiu1}'),
              Text('Actividad: ${welcome.actividad}'),
              // Agrega más campos aquí...
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Cierra el diálogo
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }
}
